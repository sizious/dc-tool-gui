---------------------------------------------------------------------
"POWERED BY DELPHI" button images
Package-Version 2.9 from 09-Aug-2000

Join the "POWERED BY DELPHI" campaign by putting the corresponding
"Button" in your applications' About-boxes - thus demonstrating
the Power of Delphi as development tool!

These images have been created by various Delphi-Programmers and sent
to me for public domain. You are not only free, but even *invited* to
use them on your website or especially in your Delphi programs.

If you use these images, I'd be happy if you would put a link to my
website, the "Delphi-Box" somewhere on your pages, in your Readme
file or your application.

---------------------------------------------------------------------
Freeware, published by Richey Fellner (Support@Inner-Smile.com)
Internet: http://www.Inner-Smile.com
Please visit our site for updated versions of this file and
other useful programming tools.

The "Powered By Delphi" campaign is now also officially supported
by Borland, find details at http://www.borland.com/delphi/standup/.
Official Borland logos to be used for other purposes can be found
at http://www.borland.com/logos/ .
If any of the above links should change, their updated locations
will be linked from Richey's DELPHI-BOX.

Please note:
To keep everything together and to ease reaching our goal, this 
package should NOT BE DISTRIBUTED (also in modified form) without 
explicit permission by me. Thanks for your understanding.
---------------------------------------------------------------------
Athena12.BMP	12950 Bytes by Herman Combrink <hcombrink@homechoice.co.za>
BuiltWith.BMP    9570 Bytes "Built with.." D1-styled by Roelof Engelbrecht
BuiltWith2.BMP   3358 Bytes -""- by Ruud Harbers  75x30x256 version
BuiltWith3.BMP   6298 Bytes -""- by Ruud Harbers 113x45x256 version
DPower16.BMP     2578 Bytes optimized by me for 256 colors
DPowr256.BMP     5834 Bytes optimized by me for 16 colors
DPowerSm.BMP    10854 Bytes 256 colors, small
DPowerBW.BMP    12790 Bytes b/w, by Jurjen Dijkstra
DPower256_2.BMP  3894 Bytes by me (88x32, 256 colors)
DPower256_3.BMP  3358 Bytes by me (my favourite one - SMALL and NICE.)
D3Power.BMP     14158 Bytes by Jan Jacobs
D4Power.JPG      3626 Bytes by PcBob (Slobodan Miscovic)
D4Power1.BMP    14710 Bytes by PcBob (Slobodan Miscovic)
D4Power2.BMP    14158 Bytes by Jan Jacobs
D5Alien.JPG	 7566 Bytes by Rory Sandoval Rueda <rory@infonet.com.bo> :-)
Delphi4.GIF      2864 Bytes by Florian Robardet
Delph256.BMP     5238 Bytes by Chris Cowherd
Delp256B.BMP     5446 Bytes like above, with Athena (by me)
Delp256C.BMP     4850 Bytes by me
Delp256D.BMP     4482 Bytes smaller version of "C", by me
Delp256E.BMP     3288 Bytes more colorized version of "D", by me
DExpert.GIF      2405 Bytes "Expert in Delphi" variation -
                            same design as DPower256_3 ("Powered By..")
Animations:
AnDelphi1.GIF   57717 Bytes animated GIF image by Danilo Fernandes
AnDelphi2.GIF   20615 Bytes = AnDelphi1, optimized by Erik Radius
DelpGear.GIF    12459 Bytes animated GIF image by John Gonzalez
Others:
CPower.BMP       5196 Bytes "Powered by C++" variation by Robert Penz
CBuilder.BMP     5408 Bytes "Powered by C-Builder" by Robert Penz
CBuilder3.BMP   11112 Bytes by James Lee Tabor
JPower.BMP       5208 Bytes "Powered by JBuilder" variation by R.Penz
JPower.BMP       5208 Bytes "Powered by JBuilder" variation by R.Penz
-----------------------
SUBDIRECTORY "BORLAND":
This subdirectory contains some Delphi and BCB splash screen varations
*officially* published by Borland in the Delphi newsgroups in Feb. and
March 1999. Thanks to Borland for allowing us to use them!
AbsolutD.jpg	 by Anders Ohlsson (Borland)
Delphi3.jpg	 by Anders Ohlsson (Borland)
Delphi4_FT3.jpg  by Anders Ohlsson (Borland)
Delphi4_RC2.jpg  by Anders Ohlsson (Borland)
Delphi4_RTM.jpg  by Anders Ohlsson (Borland)
BuiltFor.gif	 "Built for Delphi" button by Borland
ExpertIn.gif	 "Expert in Delphi" button by Borland
PoweredBy.gif	 "Powered by Delphi" button by Borland
Powered.gif	 "Powered by Delphi" button (animated) for webpages
BCB_ft1.JPG	 by Anders Ohlsson (Borland)
BCB_Internal.jpg by Anders Ohlsson (Borland)
BCB_Launcher.jpg by Anders Ohlsson (Borland)
BCB_rtm.jpg      by Anders Ohlsson (Borland)
-- variations:
Groucho.jpg	"Groucho Marx" variation, created by Marko Peric
----------------------------------------------------------------<EOF>